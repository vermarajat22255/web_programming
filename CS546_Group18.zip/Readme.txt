use seed.js to populate data 

CS546 Final Project: Ticker Talk

Group Member: (Group 18)

Rajat Verma
Ankit Talaviya
Neil Sharma
Deep Chitroda

GitHub Link: 

Setup Guide:

"npm install": Install all the modules

"npm run-script seed": Seed the database with initial data

"npm start": Start Web server


Extra Feature:
Search by speech : Initialize the speech script by double tapping any where in body when you want to control
Say -signup : (if it hears something like sign, it will lead you to signup page),
     login - (leads to login page)
     any stockname : leads to search results
     If not these 3, will notify invalid search query]
